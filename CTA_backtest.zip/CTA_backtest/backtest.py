import pandas as pd  
import numpy as np 
import os 
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']  
plt.rcParams['axes.unicode_minus'] = False
import seaborn as sns
import warnings
from tqdm import tqdm
from .CTA_BC.preprocess._plot import _plot_pnl
from .CTA_BC.trade.trade_boll import trade_ori,create_trade_flag
from .CTA_BC.metrics.cal_return import calculate_returns_all,calculate_returns_folds
from .CTA_BC.metrics.cal_indicator import cal_metric
from sklearn.utils.validation import check_is_fitted

class BackTest:
    def __init__(self):
        pass
    def fit(self,df_x,product_list,name,begin_date = '2018-01-01',end_date = '2024-08-04',cost = 0,mode = 'trade_ori',ratio = 1,df_amt = None,amt_threshold = 20 * 1e8):
        _df_x = df_x.sort_index()
        self.product_list = product_list
        self.name = name
        self.cost = cost
        self.begin_date = begin_date
        self.end_date = end_date
        self.flag = create_trade_flag(df = _df_x,product_list = product_list,begin_date = begin_date,end_date = end_date,mode = mode,ratio = ratio,df_amt = df_amt,amt_threshold = amt_threshold)
        self._fitted = True

    def report(self,df_y,fold = 24,path = None):
        check_is_fitted(self,attributes=['_fitted'])
        df_y = df_y[(df_y.index>=self.begin_date)&(df_y.index<=self.end_date)]
        self.clean_product_list = [i.split('_')[0] for i in self.flag.columns]
        self._df_ret_all,self._df_ret_long,self._df_ret_short = calculate_returns_all(df_x = self.flag,df_y = df_y,product_list = self.clean_product_list,cost = self.cost)
        self.clean_product_list = [i.split('_')[0] for i in self._df_ret_all.columns]
        self.df_fold = calculate_returns_folds(df_x = self.flag,df_y = df_y,product_list = self.clean_product_list,fold = fold)
        self.df_pnl,self._dict = cal_metric(df_all = self._df_ret_all,df_long = self._df_ret_long,df_short = self._df_ret_short)
        _plot_pnl(df = self.df_pnl,_dict = self._dict,df_fold = self.df_fold,name = self.name,path = path)