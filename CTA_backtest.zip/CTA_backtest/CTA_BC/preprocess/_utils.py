def get_clean_product():
   product_list = ['CJ',  'SP',  'NR',  'P',  'BU',  'CU',  'AO',  'V',  'FG',  'L',  'UR',  'CF',  'IF',  'SM',  'RR',  'SC',  'PF',  'TL',  'IH',  'JM',  'EC',  'AU','C',  
                'AG',  'RS',  'MA',  'PG',  'RM',  'T',  'LH',  'SH',  'RU',  'CS','TA',  'IC',  'PB',  'BC',  'EB',  'SR',  'FU',  'CY',  'TF',  'SS',  'ZC',  'TS',  'SF','AP',
                'I',  'SN',  'WH',  'OI',  'ZN',  'B',  'Y',  'IM',  'LC',  'SA',  'M',  'RB',  'PX',  'EG',  'PP',  'AL',  'J',  'JD',  'LU',  'NI',  'HC',  'A',  'PK'] 
   return product_list

def get_group_product():
   product_dict = {'农产品': ['OI', 'B', 'RM', 'P', 'M', 'Y'],
                   '化工和能源': ['PG','L','EB','EG','BU','LU','PP','V','PF','MA','FU','PX','SC','TA'],
                   '金属': ['ZN', 'CU', 'AL', 'BC', 'SN'],
                   '股指': ['IC', 'IH', 'IF', 'IM'],
                   '债券': ['TS', 'TL', 'T', 'TF'],
                   '黑色系': ['HC', 'JM', 'I', 'J', 'RB']}
   return product_dict
