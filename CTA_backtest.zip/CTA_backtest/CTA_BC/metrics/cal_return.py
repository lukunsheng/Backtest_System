import pandas as pd  
import numpy as np 
import os 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from tqdm import tqdm

def calculate_returns(df,cost):
    open_prices = {'long': None, 'short': None}
    for i, row in df.iterrows():
        if row['position'] == 1:
            # 开多仓
            open_prices['long'] = row['price']
        elif row['position'] == -1:
            # 开空仓
            open_prices['short'] = row['price']
        elif row['position'] == 0:
            if open_prices['long'] is not None:
                # 平多仓
                df.at[i, 'return_long'] = ((row['price'] / open_prices['long']) - 1) - cost
                open_prices['long'] = None
            if open_prices['short'] is not None:
                # 平空仓
                df.at[i, 'return_short'] = (1 - (row['price'] / open_prices['short'])) - cost
                open_prices['short'] = None
    _df_pnl = df.loc[:,['return_long','return_short']]    
    _df_pnl['return'] = np.where(
                                (_df_pnl['return_long'].isna() & _df_pnl['return_short'].isna()), 
                                np.nan, 
                                _df_pnl['return_long'].fillna(0) + _df_pnl['return_short'].fillna(0)
                            )
    return _df_pnl



def calculate_returns_all(df_x,df_y,product_list,cost = 0):
    _df_ret_long = pd.DataFrame(index=df_y.index)
    _df_ret_short = pd.DataFrame(index=df_y.index)
    _df_ret_all = pd.DataFrame(index=df_y.index)
    for product in tqdm(product_list):
        base_price = df_y.loc[:,[product]]
        factor_flag = df_x.loc[:,[product]].dropna()

        # if len(factor_flag.dropna()) <= 100: #过滤僵尸品种
        #     continue
        base_price = base_price[base_price.index >= '2018-01-01']
        base_price.columns = ['price']
        factor_flag.columns = ['position']
        _df = pd.merge(base_price, factor_flag, on='datetime', how='right')
        _df.sort_index(inplace = True)

        _df['return_long'] = np.nan
        _df['return_short'] = np.nan
        # _df.columns = ['price', 'position', 'return_long', 'return_short']
        _df_ret = calculate_returns(df=_df, cost=cost)

        _df_ret_long[f'{product}_long'] = np.nan
        _df_ret_short[f'{product}_short'] = np.nan
        _df_ret_all[f'{product}_all'] = np.nan
        _df_ret_long.loc[_df_ret.index, f'{product}_long'] = _df_ret['return_long']
        _df_ret_short.loc[_df_ret.index, f'{product}_short'] = _df_ret['return_short']
        _df_ret_all.loc[_df_ret.index, f'{product}_all'] = _df_ret['return']
        
    return _df_ret_all,_df_ret_long,_df_ret_short


def calculate_returns_folds(df_x,df_y,product_list,fold = 24):

    long_fold = pd.DataFrame()
    long_fold.index.name = 'fold_num'
    short_fold = pd.DataFrame()
    short_fold.index.name = 'fold_num'
    df_y = df_y.sort_index()
    
    for product in product_list:
        base_data = df_y.loc[:,[product]].dropna()

        for i in range(1,fold+1):
            base_data[f'fold_{i}'] = (base_data[product].shift(-i) - base_data[product].shift(-i+1))/base_data[product]
        _fold_data = base_data.loc[:,[f'fold_{i}' for i in range(1,fold+1)]]

        _f = df_x.loc[:,[product]]
        _f_long = _fold_data.loc[_f[_f[_f.columns[0]] == 1].index,:]
        _f_short = _fold_data.loc[_f[_f[_f.columns[0]] == -1].index,:]
        
        _t_long = pd.DataFrame(_f_long.sum())
        _t_short = pd.DataFrame(_f_short.sum()) 
        _t_short = -_t_short
        _t_long.index.name = 'fold_num'
        _t_long.columns = [product]
        _t_short.index.name = 'fold_num'
        _t_short.columns = [product]
        
        long_fold = pd.merge(long_fold, _t_long, on = 'fold_num',how = 'outer')
        short_fold = pd.merge(short_fold, _t_short, on = 'fold_num',how = 'outer')
    df_fold = pd.concat([long_fold.sum(axis = 1),short_fold.sum(axis = 1)],axis=1)
    df_fold.columns = ['long_fold','short_fold']
    df_fold['all_fold'] = df_fold.sum(axis = 1)
    df_fold = df_fold/abs(df_fold).sum()
    df_fold = round(df_fold * 100, 1)
    df_fold.index = [j.split('_')[1] for j in df_fold.index]
    df_fold.index = df_fold.index.astype(int)
    df_fold = df_fold.sort_index()
    
    return df_fold