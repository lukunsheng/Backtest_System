import pandas as pd  
import numpy as np 
import os 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
from tqdm import tqdm

def cal_metric(df_all,df_long,df_short):
    
    _df_all = pd.DataFrame(df_all.sum(axis = 1),columns = ['return_all'])
    _df_long = pd.DataFrame(df_long.sum(axis = 1),columns = ['return_long'])
    _df_short = pd.DataFrame(df_short.sum(axis = 1),columns = ['return_short'])

    df_plot = pd.merge(_df_all,_df_long,on = 'datetime',how = 'left')
    df_plot = pd.merge(df_plot,_df_short,on = 'datetime',how = 'left')
    df_pnl = df_plot.cumsum()

    all_win_rate = (df_all > 0).sum().sum() / (pd.notnull(df_all)).sum().sum()
    long_win_rate = (df_long > 0).sum().sum() / (pd.notnull(df_long)).sum().sum()
    short_win_rate = (df_short > 0).sum().sum() / (pd.notnull(df_short)).sum().sum()

    all_ProfitLoss_ratio = df_all[df_all > 0].sum().sum() / abs(df_all[df_all < 0]).sum().sum()
    long_ProfitLoss_ratio = df_long[df_long > 0].sum().sum() / abs(df_long[df_long < 0]).sum().sum()
    short_ProfitLoss_ratio = df_short[df_short > 0].sum().sum() / abs(df_short[df_short < 0]).sum().sum()

    count_all = (pd.notnull(df_all)).sum().sum()
    count_long = (pd.notnull(df_long)).sum().sum()
    count_short = (pd.notnull(df_short)).sum().sum()

    MeanRet_all = df_all.sum().sum() / count_all
    MeanRet_long = df_long.sum().sum() / count_long
    MeanRet_short = df_short.sum().sum() / count_short
    day_len = len(pd.Series(df_all.index).apply(lambda x: str(x)[:10]).unique())

    count_all_D = count_all/day_len
    count_long_D = count_long/day_len
    count_short_D = count_short/day_len

    all_profit = df_pnl['return_all'][-1]
    long_profit = df_pnl['return_long'][-1]
    short_profit = df_pnl['return_short'][-1]

    _dict = {
            'all_win_rate': all_win_rate,
            'long_win_rate': long_win_rate,
            'short_win_rate': short_win_rate,
            'all_ProfitLoss_ratio': all_ProfitLoss_ratio,
            'long_ProfitLoss_ratio': long_ProfitLoss_ratio,
            'short_ProfitLoss_ratio': short_ProfitLoss_ratio,
            'MeanRet_all': MeanRet_all,
            'MeanRet_long': MeanRet_long,
            'MeanRet_short': MeanRet_short,
            'count_all': count_all,
            'count_long': count_long,
            'count_short': count_short,
            'count_all_D': count_all_D,
            'count_long_D': count_long_D,
            'count_short_D': count_short_D,
            'all_profit': all_profit,
            'long_profit': long_profit,
            'short_profit': short_profit
            }
    
    return df_pnl,_dict